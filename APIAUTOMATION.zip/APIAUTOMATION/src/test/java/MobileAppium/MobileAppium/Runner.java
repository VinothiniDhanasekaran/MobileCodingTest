package MobileAppium.MobileAppium;

import org.testng.annotations.Test;

public class Runner {
	
	Android_Steps and = new Android_Steps();
	Ios_Steps ios= new Ios_Steps();
	
	@Test(priority=1, enabled=true)
	
	public void TC01() {
		
		String output = and.Mobile_DataList();
		System.out.println(output);
	}
	
	public void TC02() {
		
		String output = ios.Mobile_DataList();
		System.out.println(output);
	}

}
