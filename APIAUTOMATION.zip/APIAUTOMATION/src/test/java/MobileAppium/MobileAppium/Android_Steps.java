package MobileAppium.MobileAppium;

import org.testng.annotations.Test;

import java.util.List;

import org.openqa.selenium.By;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.connection.*;

public class Android_Steps {

	public static AndroidDriver<AndroidElement> adriver ;
	
	@Test
	public String Mobile_DataList() {
		System.out.println("List the Data from application");
		String result="";
		try {
			adriver= Android_Util.launchapp();
			
			List<AndroidElement> textelements = (List<AndroidElement>) adriver.findElementByAndroidUIAutomator("new UiSelector().className(\"android.widget.TextView\")");
			for(AndroidElement element : textelements) {
				System.out.println(element.getText());
			}
	
		}
		catch(Exception e) {
			e.getMessage();
		}
		
		finally {
			adriver.quit();
		}
		
		return result;
		
	}
}
