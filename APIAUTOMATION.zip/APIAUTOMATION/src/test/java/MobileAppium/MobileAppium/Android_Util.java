package MobileAppium.MobileAppium;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;
import io.appium.java_client.remote.MobileCapabilityType;

public class Android_Util {
	
	public static AndroidDriver<AndroidElement> launchapp() throws InterruptedException, MalformedURLException{
		
		System.out.println("Test execution starts");
		DesiredCapabilities caps = new DesiredCapabilities();
		
		caps.setCapability("browserstack.user", "vinothinidhanase_tjhzrs");
		caps.setCapability("browserstack.key", "Shg9bXPsGxGkpgrQMdZ3");
		caps.setCapability("browserstack.debug", "true");
		caps.setCapability("app","bs://aa6dd82fe35dc21ba708d0429a9290053b5f9852");
		caps.setCapability("device", "Google Pixel 5");
		caps.setCapability("os_version", "12.0");
		caps.setCapability("fullReset", true);
		caps.setCapability("noReset", false);
		caps.setCapability("project", "First Application");
		caps.setCapability("build", "Java Android");
		caps.setCapability("name", "AndroidMobileTesting");
		caps.setCapability("webdriver.http.factory", "apache");
		caps.setCapability("autoGrantPermissions", "true");
		caps.setCapability("autoDissmissAlerts", "true");
		caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, "UiAutomator2");
		
		System.out.println("Launch the App");
		AndroidDriver<AndroidElement> driver = new AndroidDriver<AndroidElement>(new URL("http://hub.browserstack.com/wd/hub"),caps);
		Thread.sleep(8000);
		return driver;
		
	}
	
public static IOSDriver<IOSElement> launchappios() throws InterruptedException, MalformedURLException{
		
		System.out.println("Test execution starts");
		DesiredCapabilities caps = new DesiredCapabilities();
		
		caps.setCapability("browserstack.user", "vinothinidhanase_tjhzrs");
		caps.setCapability("browserstack.key", "Shg9bXPsGxGkpgrQMdZ3");
		caps.setCapability("browserstack.debug", "true");
		caps.setCapability("app","bsvalue");
		caps.setCapability("device", "iphone 12");
		caps.setCapability("os_version", "14");
		caps.setCapability("fullReset", true);
		caps.setCapability("noReset", false);
		caps.setCapability("project", "First Application");
		caps.setCapability("build", "Java ios");
		caps.setCapability("name", "iosMobileTesting");
		caps.setCapability("webdriver.http.factory", "apache");
		caps.setCapability("autoGrantPermissions", "true");
		caps.setCapability("autoDissmissAlerts", "true");
	
		
		System.out.println("Launch the App");
		IOSDriver<IOSElement> driver = new IOSDriver<IOSElement>(new URL("http://hub.browserstack.com/wd/hub"),caps);
		Thread.sleep(8000);
		return driver;
		
	}

}
