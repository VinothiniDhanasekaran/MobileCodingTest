package MobileAppium.MobileAppium;

import java.util.List;

import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.ios.IOSElement;

public class Ios_Steps {
	
	public static IOSDriver<IOSElement> idriver ;
	
	public String Mobile_DataList() {
		System.out.println("List the Data from application");
		String result="";
		try {
			idriver= Android_Util.launchappios();
			
			List<IOSElement> textelements = idriver.findElementsByXPath("//XCUIElementTypeStaticText");
			for(IOSElement element : textelements) {
				System.out.println(element.getText());
			}
	
		}
		catch(Exception e) {
			e.getMessage();
		}
		finally {
			idriver.quit();
		}
		
		return result;
		
	}
}
